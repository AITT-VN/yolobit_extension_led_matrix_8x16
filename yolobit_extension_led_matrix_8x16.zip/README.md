# yolouno_extension_led_matrix_8x16
Mục mở rộng của Yolo UNO cho module led matrix 16x8